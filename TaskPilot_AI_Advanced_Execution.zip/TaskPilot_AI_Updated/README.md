# TaskPilot AI — Action-first productivity agent

TaskPilot turns an instruction into a timed action plan with detailed tasks, step-by-step guidance, resources/materials, and a definition of done.

## Improvements in this version
- **Short time limits:** understands instructions such as “finish my assignment within 1 hour”, “revise CN in 30 minutes”, and “I have two hours to prepare”. It creates a compact set of tasks with time estimates that fit within the stated window.
- **Automatic plan length:** when no time window or duration is stated, `Auto (recommended)` estimates a suitable duration.
- **Day and date windows:** instructions such as “today”, “tonight”, “tomorrow”, “this week”, and “this month” keep the plan inside the requested period. “Starting tomorrow for 7 days” keeps the full seven-day duration.
- **Plain, friendly language:** task cards use direct, everyday wording, practical steps, resources, estimated time and a clear “you'll know it's done when” check.
- **Reminders:** users can enable browser notifications, create a reminder for a date/time, or select “Remind me” on a task. Short-deadline plans automatically add progress and deadline time-check reminders.
- **Task completion and progress:** check tasks off, track plan progress, create routines, use the focus timer, save reflections, and export the plan as JSON.
- **Smart priority engine:** ranks open tasks using importance, planned date urgency, estimated effort and whether earlier tasks remain unfinished. Scores are transparent heuristics, not a trained AI model.
- **Schedule recovery:** overdue open tasks are automatically moved forward when the app is reopened; users can also manually reschedule unfinished tasks. Completed tasks stay completed. The plan end date can extend if work is delayed.
- **Trigger-based actions:** task completion refreshes the next recommended action and can show a browser notification when notifications are allowed. Short-window plans create progress/deadline time checks.
- **Progress risk check:** estimates whether remaining task time fits the remaining schedule and flags overdue work or a likely time crunch. This is a rough estimate, not a guarantee.
- **What-if preview:** preview how delaying the next recommended task by 1, 2, 3 or 7 days could move the plan end date; previewing does not change the schedule.
- **Multi-step execution loop:** shows plan progress, highlights the next recommended task, refreshes the action queue after completion and adapts dates when overdue work is detected.
- **Calendar file export:** export task dates as an `.ics` file for import into a calendar app. This is not live calendar synchronization.
- **Domain-aware planning:** includes checklists for study/exam preparation, assignments, software/website projects, learning, general goals and house construction.
- **Safety for large goals:** when a large project is given a very short deadline, the app explains that the plan covers useful actions within the time available and does not guarantee the whole project can be finished.

## Run on Windows
1. Extract this folder and open it in VS Code.
2. Open **Terminal → New Terminal**.
3. Install packages (only needed once):
   ```powershell
   py -m pip install -r requirements.txt
   ```
4. Start the server:
   ```powershell
   py app.py
   ```
5. Open **http://127.0.0.1:8000** in your browser. Keep the terminal open while using the app.
6. Optional backend check: **http://127.0.0.1:8000/docs**

## Notification limitation to know
This prototype uses browser notifications and browser timers. To receive alerts, allow notifications and keep TaskPilot open in a browser tab. If browser notifications are not allowed, an in-page reminder falls back to an alert while the page is open. It **cannot reliably send notifications while the browser is fully closed**. Reliable background/push reminders would need a deployed backend, a database, a scheduler and web push service.

## Features planned for a later stage
Team allocation based on real skills and availability, live Google/Outlook calendar sync, persistent cross-device task storage, background push notifications, and learning time estimates from long-term performance history are not implemented yet. Calendar support currently means `.ics` export only; team members and availability are not connected to accounts.

## Prototype limitation
The planner is currently **rule-based**, not connected to a real large language model. It uses templates and duration rules, so it can still misunderstand unusual instructions. For truly open-ended generation, connect a real LLM through the Python backend, validate its structured output, and keep API keys on the server.

## Before public deployment
Add authentication, per-user database storage, HTTPS, secure validation/rate limits, a privacy policy, and a persistent reminder scheduler. Current plans, routines and reminders are saved in the browser's local storage on this device, not in a shared account.
