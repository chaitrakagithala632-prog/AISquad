const $ = (id) => document.getElementById(id);
const STORE = "taskpilot_v1_state";
const todayKey = () => { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`; };
const addDaysKey = (key, days) => { const d=new Date(`${key||todayKey()}T12:00:00`); d.setDate(d.getDate()+days); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`; };
const dateLabel = (key) => key ? new Date(`${key}T12:00:00`).toLocaleDateString(undefined,{month:"short",day:"numeric"}) : "Unscheduled";
const defaultState = () => ({planTitle:"",scheduleWindow:"",planStartDate:todayKey(),planDays:0,hoursPerDay:2,tasks:[],routines:[],reminders:[],reflections:[],streak:0,lastActive:"",rescheduleLog:[]});
let state = loadState();
let timerSeconds = 25*60;
let timerInterval = null;
let timerRunning = false;

function loadState(){
  try { return {...defaultState(), ...JSON.parse(localStorage.getItem(STORE) || "{}")}; }
  catch { return defaultState(); }
}
function persist(){ localStorage.setItem(STORE, JSON.stringify(state)); renderAll(); }
function escapeHTML(value=""){return String(value).replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function say(message,type=""){const el=$("messageArea");el.textContent=message;el.className=type;}
function taskDate(t){return t.scheduledDate || addDaysKey(state.planStartDate || todayKey(), Math.max(0,(Number(t.day)||1)-1));}
function taskPriorityScore(t,index){
 const base={high:40,medium:25,low:10}[String(t.priority||"medium").toLowerCase()]||20;
 const due=taskDate(t), today=todayKey(), delta=Math.round((new Date(`${due}T12:00:00`)-new Date(`${today}T12:00:00`))/86400000);
 const urgency=delta<0?35:delta===0?28:delta<=2?20:delta<=7?10:0;
 const effort=Number(t.estimate_minutes)||30; const effortBonus=effort<=20?7:effort<=45?4:effort>=180?3:0;
 const priorOpen=state.tasks.slice(0,index).some(x=>!x.completed);
 const dependencyPenalty=priorOpen?8:0;
 return base+urgency+effortBonus-dependencyPenalty;
}
function priorityReason(t,index){
 const due=taskDate(t), delta=Math.round((new Date(`${due}T12:00:00`)-new Date(`${todayKey()}T12:00:00`))/86400000);
 const reasons=[]; if(String(t.priority).toLowerCase()==="high")reasons.push("important task");
 if(delta<0)reasons.push("past its planned date");else if(delta===0)reasons.push("planned for today");else if(delta<=2)reasons.push("deadline is close");
 if(Number(t.estimate_minutes)<=30)reasons.push("quick to make progress on");
 if(state.tasks.slice(0,index).some(x=>!x.completed))reasons.push("earlier work is still open");
 return reasons.slice(0,2).join(" · ") || "fits the current plan";
}
function getOpenTasks(){return state.tasks.map((t,i)=>({...t,_index:i,_score:taskPriorityScore(t,i)})).filter(t=>!t.completed).sort((a,b)=>b._score-a._score);}
function assessRisk(){
 const open=state.tasks.filter(t=>!t.completed); if(!state.tasks.length)return {level:"Waiting for your plan",text:"Build an action plan first.",reasons:[]};
 const today=todayKey(); const overdue=open.filter(t=>taskDate(t)<today); const remainingMinutes=open.reduce((sum,t)=>sum+(Number(t.estimate_minutes)||30),0);
 const end=state.planEndDate || addDaysKey(state.planStartDate||todayKey(),Math.max(0,(state.planDays||1)-1));
 const daysLeft=Math.max(0,Math.round((new Date(`${end}T12:00:00`)-new Date(`${today}T12:00:00`))/86400000)+1);
 const capacity=daysLeft*Math.max(1,Number(state.hoursPerDay)||2)*60;
 const reasons=[]; if(overdue.length)reasons.push(`${overdue.length} unfinished task${overdue.length===1?" is":"s are"} past the planned date`);
 if(remainingMinutes>capacity)reasons.push(`about ${Math.ceil(remainingMinutes/60)} hours remain, but the current plan has room for about ${Math.floor(capacity/60)} hours`);
 if(open.length>=4&&daysLeft<=2)reasons.push(`${open.length} tasks remain with only ${daysLeft} day${daysLeft===1?"":"s"} left`);
 if(!open.length)return {level:"Completed",text:"All tasks in this plan are complete. Nice work!",reasons:["You finished the current action list."]};
 if(overdue.length||remainingMinutes>capacity||daysLeft<=1&&open.length>2)return {level:"At risk",text:"This plan may need a schedule change. Start with the highest-priority task or reschedule the unfinished work.",reasons:reasons.length?reasons:["The deadline is close and several tasks remain."]};
 if(daysLeft<=3||open.length>=5)return {level:"Needs attention",text:"You're still in a workable position, but check the next task and protect time for it.",reasons:reasons.length?reasons:[`${open.length} tasks are still open.`]};
 return {level:"On track",text:"Your remaining work appears to fit the current plan. Keep completing one task at a time.",reasons:[`${open.length} task${open.length===1?" remains":"s remain"} · about ${Math.ceil(remainingMinutes/60)} hours of work left.`]};
}
function renderAgentControls(){
 const open=getOpenTasks(); const risk=assessRisk();
 if($("riskTitle")){ $("riskTitle").textContent=risk.level; $("riskText").textContent=risk.text; $("riskReasons").innerHTML=risk.reasons.map(x=>`<div class="risk-reason">• ${escapeHTML(x)}</div>`).join(""); }
 const next=open[0]; if($("nextActionTitle")){ $("nextActionTitle").textContent=next?next.title:"All tasks completed"; $("nextActionText").textContent=next?`${priorityReason(next,next._index)}. About ${Number(next.estimate_minutes)||30} minutes. Planned for ${dateLabel(taskDate(next))}.`:"You've completed every task in this plan."; $("startNextTask").disabled=!next; }
 if($("priorityQueue")){ $("priorityQueue").innerHTML=state.tasks.length?open.slice(0,8).map((t,n)=>`<div class="priority-row"><span class="priority-rank">${n+1}</span><div class="priority-row-copy"><strong>${escapeHTML(t.title)}</strong><small>${escapeHTML(priorityReason(t,t._index))} · ${dateLabel(taskDate(t))} · ${Number(t.estimate_minutes)||30} min</small></div><span class="priority-score">${t._score}</span><button type="button" class="mini-action" data-open-task="${t._index}">View</button></div>`).join(""):'<p class="subtle">Generate a plan to see your ranked tasks.</p>'; $("priorityQueue").querySelectorAll("[data-open-task]").forEach(b=>b.addEventListener("click",()=>{document.querySelector('[data-view="overview"]').click();const card=document.querySelectorAll(".task-card")[Number(b.dataset.openTask)];if(card){card.scrollIntoView({behavior:"smooth",block:"center"});card.style.outline="2px solid #7c6cf2";setTimeout(()=>card.style.outline="",1800);}})); }
 if($("loopExecute")){ $("loopExecute").classList.toggle("active",state.tasks.some(t=>t.completed)); $("loopAdapt").classList.toggle("active",(state.rescheduleLog||[]).length>0 || risk.level==="At risk"); }
 if($("agentLoopStatus")){ const done=state.tasks.filter(t=>t.completed).length; $("agentLoopStatus").textContent=state.tasks.length?`${done} of ${state.tasks.length} tasks complete. ${next?`Next up: ${next.title}.`:"The current plan is complete."}${(state.rescheduleLog||[]).length?` Schedule updates made: ${state.rescheduleLog.length}.`:""}`:"Generate a plan to start the action loop."; }
}
function autoRescheduleOverdue(fromCompletion=false){
 if(!state.tasks.length)return false;
 const today=todayKey(); const overdue=state.tasks.some(t=>!t.completed&&taskDate(t)<today);
 if(!overdue)return false;
 const open=state.tasks.map((t,i)=>({t,_i:i})).filter(x=>!x.t.completed).sort((a,b)=>taskDate(a.t).localeCompare(taskDate(b.t))||a._i-b._i);
 let cursor=today; let moved=0; let previousDate="";
 open.forEach(x=>{const t=x.t;const old=taskDate(t); if(old<today || previousDate && old<previousDate){state.tasks[x._i].scheduledDate=cursor;state.tasks[x._i].day=Math.max(1,Math.round((new Date(`${cursor}T12:00:00`)-new Date(`${state.planStartDate||today}T12:00:00`))/86400000)+1);moved++;} else {cursor=old;state.tasks[x._i].scheduledDate=old;} previousDate=state.tasks[x._i].scheduledDate;cursor=addDaysKey(state.tasks[x._i].scheduledDate,1);});
 if(moved){state.planEndDate=open.reduce((max,x)=>state.tasks[x._i].scheduledDate>max?state.tasks[x._i].scheduledDate:max,state.planEndDate||today);state.rescheduleLog=state.rescheduleLog||[];state.rescheduleLog.push({at:new Date().toISOString(),moved,reason:fromCompletion?"task progress changed":"overdue tasks detected"}); if($("rescheduleMessage"))$("rescheduleMessage").textContent=`Updated ${moved} unfinished task date${moved===1?"":"s"} from today. The plan may now finish later than originally expected.`; localStorage.setItem(STORE,JSON.stringify(state)); return true; }
 return false;
}
function rescheduleRemaining(){
 if(!state.tasks.length){$("rescheduleMessage").textContent="Generate a plan first.";return;}
 const open=state.tasks.map((t,i)=>({t,_i:i})).filter(x=>!x.t.completed).sort((a,b)=>taskDate(a.t).localeCompare(taskDate(b.t))||a._i-b._i);
 if(!open.length){$("rescheduleMessage").textContent="All tasks are complete—nothing to reschedule.";return;}
 let cursor=todayKey(); let lastDay=""; let moved=0;
 open.forEach(x=>{const t=x.t;const old=taskDate(t); if(old<cursor) {state.tasks[x._i].scheduledDate=cursor;state.tasks[x._i].day=Math.max(1,Math.round((new Date(`${cursor}T12:00:00`)-new Date(`${state.planStartDate||todayKey()}T12:00:00`))/86400000)+1);moved++;} else {cursor=old;state.tasks[x._i].scheduledDate=old;} lastDay=state.tasks[x._i].scheduledDate;cursor=addDaysKey(lastDay,1);});
 state.planEndDate=lastDay;state.rescheduleLog=state.rescheduleLog||[];state.rescheduleLog.push({at:new Date().toISOString(),moved,reason:"manual recovery"});persist();$("rescheduleMessage").textContent=`Schedule reviewed. ${moved?`${moved} task date${moved===1?" was":"s were"} moved.`:"No date changes were needed."} The plan now ends around ${dateLabel(state.planEndDate)}.`;
}
function simulateDelay(){
 const out=$("simulationResult"); if(!state.tasks.length){out.textContent="Generate a plan first.";return;}
 const next=getOpenTasks()[0];if(!next){out.textContent="All tasks are complete. No delay to simulate.";return;}
 const delay=Number($("delayDays").value)||1; const currentEnd=state.planEndDate||todayKey(); const proposedEnd=addDaysKey(currentEnd,delay); const open=getOpenTasks().length;
 const risk=assessRisk();out.innerHTML=`If “${escapeHTML(next.title)}” is delayed by ${delay} day${delay===1?"":"s"}, the plan could finish around <strong>${dateLabel(proposedEnd)}</strong> if later tasks also shift. ${open>1?`${open-1} other unfinished task${open-1===1?" may":"s may"} be affected.`:"No later tasks are currently open."} Current project health: <strong>${escapeHTML(risk.level)}</strong>. This is a preview only; no dates have been changed.`;
}
function exportCalendar(){
 if(!state.tasks.length){say("Generate a plan before exporting it to a calendar.","error");return;}
 const esc=v=>String(v||"").replace(/\\/g,"\\\\").replace(/,/g,"\\,").replace(/;/g,"\\;").replace(/\n/g,"\\n");
 const stamp=new Date().toISOString().replace(/[-:]/g,"").replace(/\.\d{3}/,"");
 const events=state.tasks.map((t,i)=>{const d=(taskDate(t)||todayKey()).replace(/-/g,"");const next=new Date(`${taskDate(t)||todayKey()}T12:00:00`);next.setDate(next.getDate()+1);const end=`${next.getFullYear()}${String(next.getMonth()+1).padStart(2,"0")}${String(next.getDate()).padStart(2,"0")}`;return `BEGIN:VEVENT\r\nUID:${esc(t.id||`${stamp}-${i}@taskpilot`)}\r\nDTSTAMP:${stamp}\r\nDTSTART;VALUE=DATE:${d}\r\nDTEND;VALUE=DATE:${end}\r\nSUMMARY:${esc(t.title)}\r\nDESCRIPTION:${esc(t.description)}\r\nSTATUS:${t.completed?"COMPLETED":"CONFIRMED"}\r\nEND:VEVENT`;}).join("\r\n");
 const content=`BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//TaskPilot AI//Action Plan//EN\r\nCALSCALE:GREGORIAN\r\n${events}\r\nEND:VCALENDAR`;
 const blob=new Blob([content],{type:"text/calendar;charset=utf-8"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="taskpilot-plan.ics";a.click();URL.revokeObjectURL(url);say("Calendar file downloaded. Import taskpilot-plan.ics into your calendar app; this is not a live sync.","success");
}
function updateDay(){
  const d=new Date(); $("dateLabel").textContent=d.toLocaleDateString(undefined,{weekday:"long",month:"long",day:"numeric"}).toUpperCase();
  const h=d.getHours(); $("greeting").textContent=h<12?"Good morning. Let's make today count.":h<18?"Good afternoon. Keep your momentum.":"Good evening. Let's make this count.";
  if(state.lastActive!==todayKey()){state.streak=state.lastActive===new Date(Date.now()-86400000).toISOString().slice(0,10)?(state.streak||0)+1:1;state.lastActive=todayKey();localStorage.setItem(STORE,JSON.stringify(state));}
  $("streakCount").textContent=state.streak||0;
}
function renderTasks(){
 const list=$("taskList");list.innerHTML="";
 $("planTitle").textContent=state.planTitle||"Your action board";
 if(!state.tasks.length){list.innerHTML='<div class="empty-state"><div class="empty-icon">✧</div><h3>Your next achievement starts here</h3><p>Generate a plan above and your tasks will appear here.</p></div>';}
 state.tasks.forEach((t,i)=>{
  const el=document.createElement("article");el.className="task-card"+(t.completed?" completed":"");
  const steps=Array.isArray(t.action_steps)?t.action_steps:[];
  const materials=Array.isArray(t.materials)?t.materials:[];
  const whenLabel=state.scheduleWindow || `${dateLabel(taskDate(t))} · Day ${t.day}`;
  el.innerHTML=`<input class="task-checkbox" type="checkbox" aria-label="Mark task complete" ${t.completed?"checked":""}><div class="task-content"><div class="task-title-row"><h3>${escapeHTML(t.title)}</h3></div><p>${escapeHTML(t.description)}</p><div class="task-meta"><span class="task-tag">${escapeHTML(whenLabel)}</span><span class="task-tag priority-${String(t.priority).toLowerCase()}">${escapeHTML(t.priority)} priority</span><span class="task-tag">◷ About ${Number(t.estimate_minutes)||30} min</span><span class="task-tag">Priority score ${taskPriorityScore(t,i)}</span></div>${steps.length?`<details class="task-details"><summary>What to do, step by step (${steps.length})</summary><ol>${steps.map(step=>`<li>${escapeHTML(step)}</li>`).join("")}</ol></details>`:""}${materials.length?`<details class="task-details"><summary>What you'll need</summary><ul>${materials.map(item=>`<li>${escapeHTML(item)}</li>`).join("")}</ul></details>`:""}${t.success_criteria?`<div class="task-done-criteria"><strong>You'll know it's done when:</strong> ${escapeHTML(t.success_criteria)}</div>`:""}<div class="task-actions"><button class="text-btn task-remind-btn" type="button" data-remind-task="${i}">◷ Remind me</button></div></div>`;
  el.querySelector("input").addEventListener("change",e=>{
   state.tasks[i].completed=e.target.checked; state.tasks[i].completedAt=e.target.checked?new Date().toISOString():null;
   if(e.target.checked){const next=getOpenTasks()[0]; if(next && "Notification" in window && Notification.permission==="granted") { try{new Notification("TaskPilot: nice progress!",{body:`You completed “${t.title}”. Next suggested task: ${next.title}`});}catch{}} }
   autoRescheduleOverdue(true); persist();
  });
  el.querySelector("[data-remind-task]").addEventListener("click",()=>remindAboutTask(t));
  list.appendChild(el);
 });
 const total=state.tasks.length,done=state.tasks.filter(t=>t.completed).length,remaining=total-done,pct=total?Math.round(done/total*100):0;
 $("totalTasks").textContent=total;$("completedTasks").textContent=done;$("remainingTasks").textContent=remaining;$("progressText").textContent=pct+"%";$("progressFill").style.width=pct+"%";$("taskCount").textContent=`${total} ${total===1?"task":"tasks"}`;
 $("insightCompleted").textContent=done;$("insightPercent").textContent=pct+"%";
}
function renderRoutines(){
 const list=$("routineList");list.innerHTML="";
 if(!state.routines.length)list.innerHTML='<div class="empty-state"><div class="empty-icon">◷</div><h3>Your routine starts small</h3><p>Add one repeatable action you can realistically keep.</p></div>';
 state.routines.forEach((r,i)=>{
  const row=document.createElement("div");row.className="routine-row"+(r.doneDate===todayKey()?" done":"");
  row.innerHTML=`<input class="routine-check" type="checkbox" ${r.doneDate===todayKey()?"checked":""} aria-label="Complete routine"><div class="routine-info"><strong>${escapeHTML(r.name)}</strong><small>${escapeHTML(r.time)} · ${escapeHTML(r.repeat)} · ${r.doneDate===todayKey()?"Completed today":"Ready for today"}</small></div><button class="delete-btn" aria-label="Delete routine">×</button>`;
  row.querySelector("input").addEventListener("change",e=>{r.doneDate=e.target.checked?todayKey():"";persist();});
  row.querySelector("button").addEventListener("click",()=>{state.routines.splice(i,1);persist();});
  list.appendChild(row);
 });
 const done=state.routines.filter(r=>r.doneDate===todayKey()).length;
 $("routineProgressText").textContent=`${done} of ${state.routines.length} completed`;
 $("routineProgressFill").style.width=(state.routines.length?done/state.routines.length*100:0)+"%";
 $("insightRoutines").textContent=state.routines.length;
}
function renderReminders(){
 const list=$("reminderList");list.innerHTML="";
 if(!state.reminders.length){list.innerHTML='<p class="reminder-empty">No reminders yet. Add one here or use “Remind me” on any task.</p>';return;}
 state.reminders.forEach((r,i)=>{const row=document.createElement("div");row.className="reminder-item";const when=new Date(r.at).toLocaleString();row.innerHTML=`<span>◷ <strong>${escapeHTML(r.title)}</strong><small>${escapeHTML(when)}${r.fired?" · Sent":" · Waiting"}</small></span><button class="delete-btn" aria-label="Delete reminder">×</button>`;row.querySelector("button").onclick=()=>{state.reminders.splice(i,1);persist();};list.appendChild(row);});
}
async function enableNotifications(){
 if(!("Notification" in window)){say("This browser doesn't support desktop notifications. You can still see reminders while TaskPilot is open.","error");return false;}
 if(Notification.permission==="granted"){ $("notificationStatus").textContent="Notifications are enabled on this browser.";return true; }
 if(Notification.permission==="denied"){ $("notificationStatus").textContent="Notifications are blocked. Allow them in your browser's site settings, then try again.";return false; }
 const permission=await Notification.requestPermission();
 $("notificationStatus").textContent=permission==="granted"?"Notifications are enabled on this browser.":"Notifications weren't enabled. You can allow them later in your browser's site settings.";
 return permission==="granted";
}
function addReminder(title, at, source="manual"){
 const reminder={title,at:new Date(at).toISOString(),fired:false,source};
 state.reminders.push(reminder);persist();return reminder;
}
async function remindAboutTask(task){
 const allowed=await enableNotifications();
 const minutes=Math.max(5,Math.min(15,Number(task.estimate_minutes)||15));
 const at=new Date(Date.now()+minutes*60*1000);
 addReminder(`Check your progress: ${task.title}`,at,"task");
 say(allowed?`All set! I'll remind you about “${task.title}” in about ${minutes} minutes while TaskPilot is open.`:`I've saved a reminder for about ${minutes} minutes from now. Allow browser notifications if you want a pop-up while TaskPilot is open.`,allowed?"success":"");
}
function renderReflections(){
 const list=$("reflectionHistory");list.innerHTML="";
 state.reflections.slice(0,5).forEach(r=>{const el=document.createElement("div");el.className="reflection-entry";el.textContent=`${r.date} — ${r.text}`;list.appendChild(el);});
}
function renderAll(){renderTasks();renderRoutines();renderReminders();renderReflections();renderAgentControls();}

$("goalForm").addEventListener("submit",async e=>{
 e.preventDefault();const goal=$("goalInput").value.trim();if(goal.length<3){say("Please describe your goal in a little more detail.","error");return;}
 const btn=$("generateBtn");btn.disabled=true;btn.textContent="Building your plan…";say("I'm turning your instruction into a practical plan…");
 const needsTimeChecks=/\b(?:within|in|over the next|for the next|i have|got|only have)\s+(?:\d+(?:\.\d+)?|a|an|one|two|three|four|half)\s+(?:minutes?|mins?|hours?|hrs?)\b/i.test(goal);
 // Ask for notification permission during the user's click, before the network request.
 const notificationPermissionPromise=needsTimeChecks?enableNotifications():Promise.resolve(false);
 try{
  const selectedLength=$("daysInput").value;
  const response=await fetch("/api/plan",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({goal,days:selectedLength==="auto"?null:Number(selectedLength),hours_per_day:Number($("hoursInput").value)})});
  const data=await response.json();if(!response.ok)throw new Error(data.detail||data.error||"Could not generate plan.");
  state.scheduleWindow=data.scheduleWindow||"";state.planStartDate=data.startDate||todayKey();state.planDays=Number(data.days)||1;state.planEndDate=addDaysKey(state.planStartDate,Math.max(0,state.planDays-1));state.hoursPerDay=Number(data.hoursPerDay)||2;
  state.planTitle=data.planTitle+(data.scheduleWindow?` · ${data.scheduleWindow} plan`:` · ${data.days}-day plan`);
  state.tasks=(data.tasks||[]).map((t,i)=>({...t,id:`${Date.now()}-${i}`,scheduledDate:addDaysKey(state.planStartDate,Math.max(0,(Number(t.day)||1)-1)),completed:false,completedAt:null,assignedTo:t.assignedTo||""}));state.rescheduleLog=[];persist();
  let reminderMessage="";
  if(data.windowMinutes){
   const allowed=await notificationPermissionPromise;
   const mins=data.windowMinutes;
   const checkpoints=mins>=30?[Math.max(10,Math.floor(mins/2)),Math.max(1,mins-5)]:[Math.max(1,mins-2)];
   [...new Set(checkpoints)].forEach((offset,index)=>{
    const at=new Date(Date.now()+offset*60*1000);
    addReminder(index===0&&checkpoints.length>1?"Quick progress check: keep going":`Time check: ${data.scheduleWindow} deadline is coming up`,at,"plan");
   });
   reminderMessage=allowed?" I've also set a couple of time checks; keep this page open so browser reminders can appear.":" I've saved time-check reminders too. Allow browser notifications if you'd like pop-up alerts, and keep this page open.";
  }
  const caution=(data.cautions||[]).join(" ");
  say(`${data.scheduleWindow?`Here's a plan for the ${data.scheduleWindow.toLowerCase()}`:`Here's your ${data.days}-day plan`}. I've broken it into clear, manageable steps and listed what you'll need.${data.durationSource==="estimated"?" The timeline is a best estimate.":data.durationSource==="selected"?" I've kept the length you selected.":" I've used the time window from your instruction."}${reminderMessage}${caution?" Please note: "+caution:""}`,"success");
  $("tasks").scrollIntoView({behavior:"smooth",block:"start"});
 }catch(err){say(`${err.message} Is the Python server running at 127.0.0.1:8000?`,"error");}
 finally{btn.disabled=false;btn.innerHTML="<span>✦</span> Build my action plan <span>→</span>";}
});
document.querySelectorAll(".suggestion-chip").forEach(b=>b.addEventListener("click",()=>{$("goalInput").value=b.dataset.goal;$("goalInput").focus();}));
document.querySelectorAll(".nav-item").forEach(b=>b.addEventListener("click",()=>{
 document.querySelectorAll(".nav-item").forEach(n=>n.classList.remove("active"));b.classList.add("active");
 document.querySelectorAll(".view").forEach(v=>v.classList.remove("active-view"));$("view-"+b.dataset.view).classList.add("active-view");window.scrollTo({top:0,behavior:"smooth"});
}));
$("routineForm").addEventListener("submit",e=>{e.preventDefault();state.routines.push({name:$("routineName").value.trim(),time:$("routineTime").value,repeat:$("routineRepeat").value,doneDate:""});e.target.reset();$("routineTime").value="19:00";persist();});
const workflowGoals={
 exam:"Prepare for my semester exams and revise daily",
 hackathon:"Build and present a hackathon website prototype",
 routine:"Create a consistent healthy morning and evening routine",
 learn:"Learn a new programming skill and build a small project"
};
document.querySelectorAll("[data-workflow]").forEach(b=>b.addEventListener("click",()=>{$("goalInput").value=workflowGoals[b.dataset.workflow];$("daysInput").value="auto";document.querySelector('[data-view="overview"]').click();$("goalInput").scrollIntoView({behavior:"smooth",block:"center"});$("goalInput").focus();}));
$("exportBtn").addEventListener("click",()=>{
 const blob=new Blob([JSON.stringify({planTitle:state.planTitle,tasks:state.tasks,exportedAt:new Date().toISOString()},null,2)],{type:"application/json"});
 const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="taskpilot-action-plan.json";a.click();URL.revokeObjectURL(url);
});
$("enableNotificationsBtn").addEventListener("click",enableNotifications);
$("reminderForm").addEventListener("submit",async e=>{
 e.preventDefault();const title=$("reminderTitle").value.trim(),at=$("reminderTime").value;
 if(!title){say("Add a short note about what you want to remember.","error");return;}
 if(!at||new Date(at)<=new Date()){say("Choose a time in the future so I know when to remind you.","error");return;}
 const allowed=await enableNotifications();addReminder(title,new Date(at),"manual");e.target.reset();
 say(allowed?"Reminder saved. I'll show a browser notification at that time while TaskPilot is open.":"Reminder saved. To receive a pop-up, allow notifications in your browser settings and keep TaskPilot open.",allowed?"success":"");
});
function checkReminders(){
 const now=Date.now();let changed=false;
 state.reminders.forEach(r=>{if(!r.fired&&new Date(r.at).getTime()<=now){r.fired=true;changed=true;
  const body=r.title;
  if("Notification" in window&&Notification.permission==="granted"){
   try{const n=new Notification("TaskPilot reminder",{body,tag:`taskpilot-${r.at}`,renotify:false});n.onclick=()=>{window.focus();n.close();};}
   catch{say(`Reminder: ${body}`,"success");}
  }else{alert(`TaskPilot reminder: ${body}`);}
 }});
 if(changed){localStorage.setItem(STORE,JSON.stringify(state));renderReminders();}
}
$("timerStart").addEventListener("click",()=>{
 if(timerRunning){clearInterval(timerInterval);timerRunning=false;$("timerStart").textContent="▶ Resume focus";return;}
 timerRunning=true;$("timerStart").textContent="Ⅱ Pause";
 timerInterval=setInterval(()=>{timerSeconds--;updateTimer();if(timerSeconds<=0){clearInterval(timerInterval);timerRunning=false;$("timerStart").textContent="↻ Start another session";if("Notification"in window&&Notification.permission==="granted")new Notification("Focus session complete",{body:"Take a short break and celebrate the progress."});else alert("Focus session complete! Take a short break.");}},1000);
});
$("timerReset").addEventListener("click",()=>{clearInterval(timerInterval);timerRunning=false;timerSeconds=25*60;updateTimer();$("timerStart").textContent="▶ Start focus";});
function updateTimer(){$("timerDisplay").textContent=`${String(Math.floor(timerSeconds/60)).padStart(2,"0")}:${String(timerSeconds%60).padStart(2,"0")}`;}
$("saveReflection").addEventListener("click",()=>{const text=$("reflectionInput").value.trim();if(!text){$("reflectionStatus").textContent="Write a quick reflection first.";return;}state.reflections.unshift({date:new Date().toLocaleDateString(),text});state.reflections=state.reflections.slice(0,30);$("reflectionInput").value="";$("reflectionStatus").textContent="Check-in saved on this device.";persist();});
$("startNextTask").addEventListener("click",()=>{const next=getOpenTasks()[0];if(!next)return;document.querySelector('[data-view="overview"]').click();const card=document.querySelectorAll(".task-card")[next._index];if(card){card.scrollIntoView({behavior:"smooth",block:"center"});const details=card.querySelector("details");if(details)details.open=true;card.style.outline="2px solid #7c6cf2";setTimeout(()=>card.style.outline="",1800);}});
$("sortByPriority").addEventListener("click",()=>{if(!state.tasks.length){say("Generate a plan first.","error");return;}const order=getOpenTasks().map(t=>t._index);const completed=state.tasks.filter(t=>t.completed);state.tasks=[...order.map(i=>state.tasks[i]),...completed];persist();say("Action board reordered by smart priority. Original planned dates are preserved.","success");document.querySelector('[data-view="overview"]').click();});
$("rescheduleBtn").addEventListener("click",rescheduleRemaining);
$("simulateDelay").addEventListener("click",simulateDelay);
$("exportCalendar").addEventListener("click",exportCalendar);

autoRescheduleOverdue(false);updateDay();renderAll();
if($("reminderTime")){const now=new Date();now.setMinutes(now.getMinutes()-now.getTimezoneOffset());$("reminderTime").min=now.toISOString().slice(0,16);}
if("Notification" in window){$("notificationStatus").textContent=Notification.permission==="granted"?"Notifications are enabled on this browser.":Notification.permission==="denied"?"Notifications are blocked in browser settings.":"Turn on notifications to receive pop-up reminders.";}
setInterval(checkReminders,5000);
checkReminders();
